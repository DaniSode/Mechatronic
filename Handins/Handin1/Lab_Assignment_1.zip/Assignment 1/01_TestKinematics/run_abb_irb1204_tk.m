% Note: The first time you run this script, it may take some time since it
% has to load the simulink environment (usually a couple of seconds).

clear all; close all; clc
addpath('C:\Users\soder\OneDrive - Chalmers\Chalmers\Modelling and control of mechatronic systems\Mina funktioner')
testKinematics
