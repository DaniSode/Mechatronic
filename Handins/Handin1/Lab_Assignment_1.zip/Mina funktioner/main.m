% Name: Daniel Söderqivst
% Course:  Model Predictive Control
% Purpose: Exercise 1 in Assignment 1

% Clear the workspace and close any open figures
clear all; close all; clc


%% Main code 


%% Assignment 1


% Kinematic parameters
% TODO: Define the kinematic parameters.
L1=0.29;
L2=0.27;
L3=0.07;
L4=0.302;
L5=0.072;
L6=0.1; % EF offset
L7=sqrt(L3^2+L4^2);% linear offset between cf 2 and cf 3
L8=L5+L6;% linear offset between cf 4 and ef (See Figure 1 in Lab Assignment document)
al=atan(L4/L3);% angular offset between cf 2 and cf 3
L11=L1/2;
L21=L2/2;
L51=L7/2;
L41=L8/2;


% Defining q 
q1 = 0; 
q2 = 0; 
q3 = 0; 
q4 = 0;


% If wanted
% syms q1 q2 q3 q4 L1 L2 L7 L8 L11 L21 L51 L41 real

% Define DH matrix (theta, d)-z, (a and alpha)-x
DH = [q1           L1   0    -pi/2;
      q2-pi/2      0    L2       0;
      q3+al        0    L7       0;
      q4+pi/2-al   0    L8       0];

% Converting from DH to HT
HT1_0 = DHtoHT_Distal(DH,0,1);
HT2_0 = DHtoHT_Distal(DH,0,2);
HT3_0 = DHtoHT_Distal(DH,0,3);
HT4_0 = DHtoHT_Distal(DH,0,4);
fprintf('The answer to the first exercise in assignment 1:\n\n');
fprintf('HT_0^1 =\n\n');disp(HT1_0)
fprintf('HT_0^2 =\n\n');disp(HT2_0)
fprintf('HT_0^3 =\n\n');disp(HT3_0)
fprintf('HT_0^4 =\n\n');disp(HT4_0)

% Defining q 
q1 = 0; 
q2 = 0.3; 
q3 = 0; 
q4 = 0;

% Define DH matrix (theta, d)-z, (a and alpha)-x
DH = [q1           L1   0    -pi/2;
      q2-pi/2      0    L2       0;
      q3+al        0    L7       0;
      q4+pi/2-al   0    L8       0];

% Jacobian
Jef = HTtoJ(DH,0,4);
fprintf('\n\n\nThe answer to the second exercise in assignment 1:\n\n');
fprintf('J_0^ef =\n\n');disp(Jef)

% %% Assignment 2
% 
% % Defining q 
% q1 = 0; 
% q2 = 0; 
% q3 = 0; 
% q4 = 0;
% 
% 
% % Define DH matrix (theta, d)-z, (a and alpha)-x
% DH = [q1           L1   0    -pi/2;
%       q2-pi/2      0    L2       0;
%       q3+al        0    L7       0;
%       q4+pi/2-al   0    L8       0];
% 
% DHcm = [q1           L11   0        0;
%         q2-pi/2      0    L21       0;
%         q3+al        0    L51       0;
%         q4+pi/2-al   0    L41       0];
% 
% % Trying to calcualte HTcm
% HTcm1_0 = DHtoHTcm(DH, DHcm, 0, 1)
%      
% HTcm2_0 = DHtoHTcm(DH, DHcm, 0, 2)
%     
% HTcm3_0 = DHtoHTcm(DH, DHcm, 0, 3)
%     
% HTcm4_0 = DHtoHTcm(DH, DHcm, 0, 4)
% 
% 
% % Trying to calcualte Jcm
% Jcm1=HTtoJcm(DH, DHcm, 0, 1)
% 				    
% Jcm2=HTtoJcm(DH, DHcm, 0, 2)
% 				    
% Jcm3=HTtoJcm(DH, DHcm, 0, 3)
%     
% Jcm4=HTtoJcm(DH, DHcm, 0, 4)
% 
% % M matrix
% [M, C, G] = ToMCG();
% 
% % % M matrix
% % fprintf('M =\n');disp(simplify(M))
% % % C matrix
% % fprintf('C =\n');disp(simplify(C))
% % % G matrix
% % fprintf('G =\n');disp(simplify(G))
% 
% 
% %% Assignment 3
% 
% [Tau, Theta, Yr, YrBeta, YrAll] = ToTau(M,C,G);
% 
% % % % Tau matrix
% % fprintf('Tau =\n');disp(Tau)
% % 
% % % Theta matrix
% % fprintf('Theta =\n');disp(Theta)
% % 
% % % Yr matrix
% % fprintf('Yr =\n');disp(Yr)
% % % YrBeta matrix
% % fprintf('YrBeta =\n');disp(YrBeta)
% % % YrBeta matrix
% % fprintf('YrAll =\n');disp(YrAll)
