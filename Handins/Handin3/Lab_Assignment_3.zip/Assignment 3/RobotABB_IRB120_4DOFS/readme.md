# Kinematic and Dynamic models for robot AMM IRB120 with 4DOFs 

The joints 4 and 6 are considered fixed. 

This version includes addditional simplifications and optimizations.


