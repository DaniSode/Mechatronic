function L=kukaIIWA7_params
% kukaIIWA7_params Gets the Robot kinematic parameters as a vector 4x1

%Kinematic Parameters

L(1)=0.34;
L(2)=0.40;
L(3)=0.40;
L(4)=0.25;
